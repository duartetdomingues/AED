/******************************************************************************
 *
 * File Name: defs.h
 *	      (c) 2018 AED
 * Authors:    AED Team
 * Revision:  v2.4
 *
 *****************************************************************************/

#ifndef _DEFS_H_
#define _DEFS_H_

typedef void *Item;

#endif
